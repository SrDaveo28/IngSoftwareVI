﻿using IngSoftwareIV.Model;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using Dapper.Contrib.Extensions;

namespace IngSoftwareIV.Data
{
    public static class AlumnoRepository
    {
        public static void Insertar(Alumno Obj)
        {
            using (var Conexion=new MySqlConnection(ComunRepository.CadenaDeConexion))
            {
                Conexion.Insert(Obj);
            }
        }
    }
}
