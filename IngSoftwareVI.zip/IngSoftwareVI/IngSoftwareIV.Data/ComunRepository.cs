﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IngSoftwareIV.Data
{
    public  static class ComunRepository
    {
        public static string  CadenaDeConexion { get; set; }

    }
}
