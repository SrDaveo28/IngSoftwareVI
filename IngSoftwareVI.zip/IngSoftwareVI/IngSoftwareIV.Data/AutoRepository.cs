﻿using Dapper.Contrib.Extensions;
using IngSoftwareIV.Model;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
namespace IngSoftwareIV.Data
{
    public static class AutoRepository
    {
        public static void Insertar(Auto Obj)
        {
            using (var Conexion = new MySqlConnection(ComunRepository.CadenaDeConexion))
            {
                Conexion.Insert(Obj);
            }
        }
    }
}
