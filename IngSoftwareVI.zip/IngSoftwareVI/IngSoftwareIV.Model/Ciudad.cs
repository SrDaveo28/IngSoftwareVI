﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IngSoftwareIV.Model
{
    public  class Ciudad
    {
        public int IdCiudad { get; set; }    
        public string Nombre { get; set; }

    }
}
