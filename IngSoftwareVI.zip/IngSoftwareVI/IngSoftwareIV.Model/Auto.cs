﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IngSoftwareIV.Model
{
    public class Auto
    {
        public int IdAuto { get; set; }
        public string Chasis { get; set; }
        public string Chapa { get; set; }
    }
}
