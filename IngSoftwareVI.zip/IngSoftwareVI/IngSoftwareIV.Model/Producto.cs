﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IngSoftwareIV.Model
{
    public  class Producto
    {
        public int IdProducto { get; set; }
        public string Nombre { get; set; } 
        public Double PrecioCosto { get; set; }
        public Double PrecioVenta { get; set; }
        public Double Stock { get; set; }

    }
}
