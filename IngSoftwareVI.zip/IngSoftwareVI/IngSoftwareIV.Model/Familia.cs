﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IngSoftwareIV.Model
{
    public  class Familia
    { 
        public int IdFamilia { get; set; }
        public string Nombre { get; set; }

    }
}
