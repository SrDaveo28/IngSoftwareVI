﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IngSoftwareIV.Model
{
    public class Cliente
    {
        public int IdCliente { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public DateTime Nacimiento  { get; set; }

        public int CantiddHijos { get; set; }
        public string Telefono { get; set; }    
        public string Direccion { get; set; }   
        public double LimiteDeCredito { get; set; }
        public bool Activo { get; set; }

    }
}
